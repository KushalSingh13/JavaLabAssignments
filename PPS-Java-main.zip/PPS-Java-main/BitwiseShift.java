public class BitwiseShift {
    public static void main(String[] args) {
        int a = 4, b = 5;

        System.out.println("a>>1=" + (a >> 1));
        System.out.println("b>>1=" + (b >> 1));
        System.out.println("a<<1=" + (a << 1));
        System.out.println("b<<1=" + (b << 1));
    }
}
