public class compile {
    public static void main(String[] args) {
        int[] array1 = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        for (int i = 0; i < array1.length; i++) {
            System.out.println(array1[i]);
        }
    }
}
