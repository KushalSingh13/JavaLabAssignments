public class SizeOf {
    public static void main(String[] args) {
        System.out.println("Size of int: " + Integer.BYTES + " bytes");
        System.out.println("Size of char: " + Character.BYTES + " bytes");
        System.out.println("Size of float: " + Float.BYTES + " bytes");
        System.out.println("Size of double: " + Double.BYTES + " bytes");
    }
}
