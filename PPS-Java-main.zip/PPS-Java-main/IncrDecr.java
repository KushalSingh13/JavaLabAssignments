public class IncrDecr {
    public static void main(String[] args) {
        int x;
        x = 0;

        System.out.println("x=" + x);
        System.out.println("x=" + x++);
        System.out.println("x=" + x);
        System.out.println("x=" + x--);
        System.out.println("x=" + x);
    }
}
