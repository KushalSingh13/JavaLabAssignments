public class BitwiseOperator {
    public static void main(String[] args) {
        int a = 11, b = 12;

        System.out.println("c=" + (a & b));
        System.out.println("c=" + (a | b));
        System.out.println("c=" + (a ^ b));
    }
}
