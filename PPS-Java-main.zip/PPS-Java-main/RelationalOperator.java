public class RelationalOperator {
    public static void main(String[] args) {
        int a, b, c;
        a = 4;
        b = 6;
        c = 8;
        System.out.println(a == b);
        System.out.println(a == c);
        System.out.println(a > b);
        System.out.println(a > c);
        System.out.println(a < b);
        System.out.println(a < c);
        System.out.println(a != c);
        System.out.println(a >= b);
        System.out.println(a <= c);
    }
}
