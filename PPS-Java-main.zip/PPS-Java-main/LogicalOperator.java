public class LogicalOperator {
    public static void main(String[] args) {
        System.out.println(8 > 7 && 5 > 8);
        System.out.println(8 > 7 || 5 > 8);
        System.out.println(8 > 7 != 5 > 8);
    }
}
